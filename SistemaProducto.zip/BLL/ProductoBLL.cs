using EL;
using DAL;

namespace BLL
{
    public class ProductoBLL
    {
        public void Insertar(Producto producto)
        {
            using (var contexto = new Contexto())
            {
                contexto.Productos.Add(producto);
                contexto.SaveChanges();
            }
        }
    }
}