using System.Data.Entity;
using EL;

namespace DAL
{
    public class Contexto : DbContext
    {
        public Contexto() : base("name=MiCadenaConexion") { }

        public DbSet<Producto> Productos { get; set; }
    }
}